# Tapmore logo kit

The mark is three QR finder corners with a clay dot in the fourth corner, the spot where the guest taps. The wordmark is set in Bricolage Grotesque 700 and converted to outlines, so the files don't need the font installed.

## Colours
| Use | Hex |
|---|---|
| Green (primary) | `#24573F` |
| Green on dark backgrounds | `#5FBF84` |
| Clay (the dot) | `#C9682C` |
| Ink (text) | `#16181A` |
| Paper (background) | `#F5F5F1` |
| Night (dark background) | `#0F1113` |

## What's where
- **web/**: drop these files into your site root and paste in `head-snippet.html`. The folder holds:
  - `favicon.ico` (16/32/48)
  - `favicon.svg`
  - favicon PNGs
  - `apple-touch-icon.png` (180)
  - Android 192/512 icons
  - a maskable 512 icon
  - `site.webmanifest`
  - `og-image.png`
- **svg/**: the master vector files. Use these wherever possible.
  - `logo.svg` is the main horizontal logo for light backgrounds.
  - `logo-on-dark.svg` is for dark backgrounds (#0F1113).
  - `logo-white.svg` is for green or photo backgrounds.
  - `logo-black.svg` is one colour, for print, stamps and receipts.
  - `logo-stacked*.svg` is the stacked version for square spaces.
  - `mark*.svg` is the symbol only. `wordmark*.svg` is the text only.
  - `icon.svg` is the rounded app icon. `icon-square.svg` is full bleed, for iOS and stores. `icon-maskable.svg` is for Android adaptive icons.
  - `favicon.svg` is pixel-tuned for 32 px. `favicon-16.svg` is a simplified version for 16 px.
  - Social templates: `og-image*.svg`, `x-header.svg`, `linkedin-banner.svg`, `social-avatar.svg`.
- **png/**: the same artwork rasterised.
  - `favicon/`: 16, 32, 48 and 64 px.
  - `app-icon/`:
    - apple-touch 180, Android 192 and 512, maskable 192 and 512
    - icon 64–1024
    - square 1024 for app stores
    - mstile 150
  - `mark/`: each colour at 64, 128, 256, 512 and 1024 px, with transparent background.
  - `logo/`:
    - horizontal at widths 320, 640, 1280 and 2560
    - stacked at 400, 800 and 1600
    - wordmark at 400 and 1200
  - `social/`:
    - avatar 400 and 800 (circle-crop safe)
    - OG image 1200×630 (light and green)
    - X header 1500×500
    - LinkedIn banner 1584×396

## Rules of thumb
- Leave clear space around the logo of at least the width of one finder square.
- Don't use the horizontal logo smaller than 100 px wide. Below that, use the mark alone. Below 24 px, use the favicon files.
- Keep the dot clay on every colour version except the one-colour black.
- In `head-snippet.html`, replace `YOUR-DOMAIN` with your domain.
